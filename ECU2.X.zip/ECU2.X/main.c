/*
 * File:   main.c
 * Author: Tejashwini
 *
 * Created on 28 September, 2026, 2:17 PM
 */


#include <xc.h>
#include "main.h"
#include "digital_keypad.h"
#include "ssd_display.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#define _XTAL_FREQ 20000000
static unsigned char ssd[MAX_SSD_CNT];

unsigned int delay = 0;
unsigned char flag = 0;
unsigned int count = 0;

void check_digital_keypad(void)
{
  
}

void init_config(void)
{
    //init_digital_keypad();
   // init_ssd_control();
    init_adc();
   

    TRISB = 0x00;
    PORTB = 0x00;
     init_can();

    TRISC = TRISC | 0x0F;
}

void main(void)
{
    unsigned short adc_reg_val;
    unsigned int rpm;

    unsigned char digit[] ={ZERO, ONE, TWO, THREE, FOUR,FIVE, SIX, SEVEN, EIGHT, NINE};

    char rpm_data[5];
      unsigned char key;

    unsigned char indicator_data[2];

    init_config();

    while(1)
    {
        
        adc_reg_val = read_adc(CHANNEL4);

        rpm = (unsigned int)((adc_reg_val / 10.23) * 60);

        
        ssd[3] = digit[rpm % 10];
        ssd[2] = digit[(rpm / 10) % 10];
        ssd[1] = digit[(rpm / 100) % 10];
        ssd[0] = digit[(rpm / 1000) % 10];

        display(ssd);

        
       // check_digital_keypad();

       
        rpm_data[0] = ((rpm / 1000) % 10 + '0');
        rpm_data[1] = ((rpm / 100) % 10 + '0');
        rpm_data[2] = ((rpm / 10) % 10 + '0');
        rpm_data[3] = (rpm % 10 + '0');
        rpm_data[4] = '\0';

       
        can_transmit(RPM_MSG_ID, rpm_data, 4);
          __delay_ms(80);
        
        
    key = read_digital_keypad(STATE_CHANGE);

    if(key == SWITCH1)
    {
        flag = 1;
        count = 0;
        PORTB = 0x00;
    }
    else if(key == SWITCH2)
    {
        flag = 2;
        count = 0;
        PORTB = 0x00;
    }
    else if(key == SWITCH3)
    {
        flag = 3;
        count = 0;
        PORTB = 0x00;
    }

    if(delay++ == 50)
    {
        if(flag == 1)
        {
            if(count % 2 == 0)
            {
                PORTB = 0x03;
            }
            else
            {
                PORTB = 0x00;
            }

            count++;
        }
        else if(flag == 2)
        {
            if(count % 2 == 0)
            {
                PORTB = 0xC0;
            }
            else
            {
                PORTB = 0x00;
            }

            count++;
        }
        else
        {
            PORTB = 0x00;
        }

        delay = 0;
    }

        
        indicator_data[0] = (flag + '0');
        indicator_data[1] = '\0';
        
     //   clcd_print(indicator_data ,LINE2(15));

        can_transmit(INDICATOR_MSG_ID, indicator_data, 1);
        
        __delay_ms(80);
    }
}